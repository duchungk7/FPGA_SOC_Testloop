// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xtestloop.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XTestloop_CfgInitialize(XTestloop *InstancePtr, XTestloop_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XTestloop_Set_A(XTestloop *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTestloop_WriteReg(InstancePtr->Axilites_BaseAddress, XTESTLOOP_AXILITES_ADDR_A_DATA, Data);
}

u32 XTestloop_Get_A(XTestloop *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTestloop_ReadReg(InstancePtr->Axilites_BaseAddress, XTESTLOOP_AXILITES_ADDR_A_DATA);
    return Data;
}

u32 XTestloop_Get_X(XTestloop *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTestloop_ReadReg(InstancePtr->Axilites_BaseAddress, XTESTLOOP_AXILITES_ADDR_X_DATA);
    return Data;
}

u32 XTestloop_Get_X_vld(XTestloop *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTestloop_ReadReg(InstancePtr->Axilites_BaseAddress, XTESTLOOP_AXILITES_ADDR_X_CTRL);
    return Data & 0x1;
}

