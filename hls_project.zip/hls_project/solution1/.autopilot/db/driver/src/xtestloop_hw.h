// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of A
//        bit 31~0 - A[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of X
//        bit 31~0 - X[31:0] (Read)
// 0x1c : Control signal of X
//        bit 0  - X_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XTESTLOOP_AXILITES_ADDR_A_DATA 0x10
#define XTESTLOOP_AXILITES_BITS_A_DATA 32
#define XTESTLOOP_AXILITES_ADDR_X_DATA 0x18
#define XTESTLOOP_AXILITES_BITS_X_DATA 32
#define XTESTLOOP_AXILITES_ADDR_X_CTRL 0x1c

